# metahash_dapps

```
Name: Singapore Culture
Decription: Malay Wedding
Img: https://github.com/coinergy/metahash_dapps/wedding.png
Link: https://github.com/coinergy/metahash_dapps/wedding.zip
Address: mh://0x00b8923f8be54f69c6b28918ceaee66bf898d052fba51fdc51
```
